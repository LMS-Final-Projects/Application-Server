package com.example.lms.application.entity;

public enum Status {
    ACCEPTED, REJECTED, PENDING
}
