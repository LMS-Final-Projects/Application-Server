package com.example.lms.global.kafka;

public enum KafkaAction {
    CREATE,UPDATE,DELETE
}